from django.apps import AppConfig


class CatalogueConfig(AppConfig):
    name = 'catalogue'
